$(document).ready(function(){
	connect();
	$("#submit").click(function(event){
		collect();
	});
});

