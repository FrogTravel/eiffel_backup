$(document).ready( function(){
	connect();
	
});
